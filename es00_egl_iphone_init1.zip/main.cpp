
#if defined(_MSC_VER)
  #pragma comment(lib, "lgpwn_b22_.lib")
  #pragma comment(lib, "lgpwn_c22_.lib")
  #pragma comment(lib, "opengl32.lib")
#endif


#if defined(_WIN32)
	#include <windows.h>

#else

	#define CALLBACK
	typedef void*	HWND;
	typedef long (CALLBACK* WNDPROC)(HWND, unsigned int, unsigned int, long);

	#include <unistd.h>

#endif

#include <gles/gl.h>
#include <gles/egl.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>




// window handle, display, surface, and rendering context for OpenGL
NativeWindowType egWnd	= NULL;				// window handle
EGLDisplay		egDsp	= EGL_NO_DISPLAY;	// EGL display
EGLSurface		egSrf	= EGL_NO_SURFACE;	// EGL rendering surface
EGLContext		egCtx	= EGL_NO_CONTEXT;	// EGL rendering context



int	 Run();
long CALLBACK MyMsgPrc(HWND, unsigned int, unsigned int, long);



NativeWindowType OS_CreateWindow(WNDPROC WndProc, char* ClassName, int ScreenW, int ScreenH)
{

#if defined(_WIN32)

	// Register Window Procedure function and create Window Handle in Win32 System
	HWND		hWnd = NULL;
	HINSTANCE	hInst = (HINSTANCE)GetModuleHandle(NULL);

	WNDCLASS	wc=
	{
		CS_HREDRAW | CS_VREDRAW
		,	WndProc
		,	0L
		,	0L
		,	hInst
		,	LoadIcon(NULL, IDI_APPLICATION)
		,	LoadCursor(NULL, IDC_ARROW)
		,	(HBRUSH)GetStockObject(WHITE_BRUSH)
		,	NULL
		,	ClassName
	};

	if( 0==	RegisterClass(&wc))
		return NULL;


	UINT dStyle=WS_VISIBLE | WS_CAPTION | WS_SYSMENU;
	RECT rc = {0,0, ScreenW, ScreenH};
	AdjustWindowRect(&rc, dStyle, 0);


	// Create Window Handle in Win32 System
	hWnd = ::CreateWindow(ClassName
						  , ClassName
						  , dStyle
						  , 1
						  , 1
						  , rc.right  - rc.left
						  , rc.bottom - rc.top
						  , NULL
						  , NULL
						  , hInst
						  , NULL);

	if (NULL == hWnd)
		return NULL;

	EnableWindow( hWnd, 1);
	SetForegroundWindow(hWnd);
	ShowWindow(hWnd, SW_SHOWNORMAL);

	return (NativeWindowType)hWnd;
#else

	// Only Create a Frame Buffer for rendering.
	return malloc( 16*1024);

#endif
}




// for the using opengl in embedded systems, u need display, surface, and rendering context.
// but window handle, device context(DC), and rendering context in windows system of PC
int InitGL(NativeWindowType hWnd)
{

// windows system for PC
#if defined(_WIN32)

	// get an display connection for the native display.
	egDsp = eglGetDisplay((NativeDisplayType)hWnd);

	// egDsp is same to DC
	if(NULL == eglCreateWindowSurface(egDsp, NULL, hWnd, 0) )
	{
		printf("eglCreateWindowSurface() Failed\n");
		return -1;
	}

	// create rendering context(RC)
	egCtx = eglCreateContext(egDsp, NULL, NULL, NULL);
	if(NULL == egCtx)
	{
		printf("eglCreateContext() Failed\n");
		return -1;
	}

// embedded system for CAANOO
#else

	// get an display connection for the native display.
	egDsp = eglGetDisplay((NativeDisplayType)EGL_DEFAULT_DISPLAY);
	if(EGL_NO_DISPLAY == egDsp)
	{
		printf("eglGetDisplay() Failed\n");
		return -1;
	}

	// Initialize the display connection.
	EGLint		ver_maj;
	EGLint		ver_min;
	if (!eglInitialize(egDsp, &ver_maj, &ver_min))
	{
		printf("eglInitialize() Failed\n");
		return -1;
	}

	// get an appropriate frame buffer to the configuration.

	struct _Tconfig_att { EGLint a; EGLint b;	};
	// CAANOO has only the pixel format, Red:8 Green:8 Blue:8 Depth:16, Stencil:0 
	// or Red:5 Green:6 Blue:5 Depth:16, Stencil:0 for frame buffer. 
	// so it is sufficient to setting the attribute that using below values.
	const _Tconfig_att config_attrib[] =
	{
		{	EGL_SURFACE_TYPE,   EGL_WINDOW_BIT, },
		{	EGL_NONE,			EGL_NONE,		},
	};


	const int	MAX_CONFIG = 10;
	int			match;
	EGLConfig	eglConf[MAX_CONFIG]={0};

	if (!eglChooseConfig(egDsp, (const EGLint*)config_attrib, &eglConf[0], MAX_CONFIG, &match))
	{
		printf("eglChooseConfig() Failed\n");
		return -1;
	}

	// there is no matching result about the configuration.
	if(1>match)
	{
		printf("eglChooseConfig() Failed\n");
		return -1;
	}

	// create a new window surface.
	egSrf = eglCreateWindowSurface(egDsp, eglConf[0], hWnd, (const EGLint*)config_attrib);
	if(EGL_NO_SURFACE == egSrf)
	{
		printf("eglCreateWindowSurface() Failed\n");
		return -1;
	}

	// create a new rendering context.
	egCtx=eglCreateContext(egDsp,eglConf[0], EGL_NO_CONTEXT, (const EGLint*)config_attrib);
	if(EGL_NO_CONTEXT == egCtx)
	{
		printf("eglCreateContext() Failed\n");
		return -1;
	}

#endif

	// connect activate the context for rendering to the surface
	if( !eglMakeCurrent(egDsp, egSrf, egSrf, egCtx) )
	{
		printf("eglMakeCurrent() Failed\n");
		return -1;
	}

	// Set the swap interval of display to immediately mode.
	// it means that buffer swaps are not synchronized to a video frame,
	// and the swap happens as soon as the render is complete.
	//if (!eglSwapInterval(egDsp, 0))
	//{
	//	printf("eglSwapInterval() Failed\n");
	//	return -1;
	//}


	printf("it was perfectly finished that the initialization for rendering.");

	return 0;
}






// OpenGL Rendering
void Render()
{
	// specify clear values(red, green, blue, alpha) for the color buffer
	glClearColor(0.8f, 0.9f, 1.0f, 1.0f);

	// Clear Color buffer and Depth Buffer.
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);





	// Setting Rendering pipeline
	glShadeModel(GL_SMOOTH);		// select smooth shading model.
	glDisable( GL_DEPTH_TEST);		// disable depth test
	glDisable( GL_CULL_FACE );		// disalbe culling face




	// Vertex Stream data
	// position buffer
	GLfloat vertexArray[9] = {  -1.F,-1.F,0.F,     1.F,-1.F,0.F,     0.F,1.F,0.F };

	// color buffer
	GLfloat colorArray[12] = { 1.F,0.F,0.F,1.F,  0.F,1.F,0.F,1.F,   0.F,0.F,1.F,0.F};

	// index buffer
	GLushort indices[3] = {0, 1, 2};


	// Position
	//Enable the vertex stream for position
	glEnableClientState(GL_VERTEX_ARRAY);

	// binding the position array to the vertex stream in pipeline
	//3 = XYZ coordinates, GL_FLOAT = data type of positon array, 0 = 0 stride bytes
	glVertexPointer(3, GL_FLOAT, 0, vertexArray);


	// Color
	//Enable the vertex stream for diffuse color
	glEnableClientState(GL_COLOR_ARRAY);

	// binding the color array to the vertex stream in pipeline
 	// 4 = RGBA format, GL_FLOAT = data type of color array, 0 = 0 stide  bytes
	glColorPointer(4, GL_FLOAT, 0, colorArray);



	// Draw with index
	// GL_TRIANGLES = primitive type, 3 = index number, GL_UNSIGNED_BYTE= index data type
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, indices);

	// you can use glDrawArrays() function without index data
	// GL_TRIANGLES = primitive type, 0 = start index 3 = number of items (vertices) to draw
	//glDrawArrays(GL_TRIANGLES, 0,3);


	// disable client-side capability
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_VERTEX_ARRAY);




	// force execution of GL commands in finite time
	// It does not wait until the execution of all previously
	// issued GL commands is complete.
	//glFlush();

	// post EGL surface color buffer to a native window
	eglSwapBuffers(egDsp, egSrf);
}





void Clean()
{
	if(NULL == egWnd)
		return;


	// Make current to null
	eglMakeCurrent(egDsp, 0, 0, 0);

	// release context, surface, and display
	eglDestroyContext(egDsp, egCtx);
	eglDestroySurface(egDsp, egSrf);

#if defined(_WIN32)
	eglTerminate((NativeDisplayType)egWnd, egDsp);
#else
	eglTerminate(egDsp);
#endif



#if defined(_WIN32)

#else
	free( egWnd );
#endif

	egSrf	= NULL;
	egCtx	= NULL;
	egDsp	= NULL;
	egWnd	= NULL;
}






int main(int argc, char** argv)
{
	// Create native window.
	egWnd = OS_CreateWindow(MyMsgPrc, (char*)"Hello CAANOO", 640, 480);
	if(NULL == egWnd)
		return 0;



	 // OpenGL ES Initialization
	if( 0 >InitGL(egWnd))
		return GL_FALSE;


	// Main Loop
	while(1)
	{
		if(0>Run())
			break;
	}


	//Clean up all
	Clean();

	// exit to main menu.
#if !defined(_WIN32)
	chdir("/usr/gp2x");
	sync();
	execl("/usr/gp2x/gp2xmenu", "/usr/gp2x/gp2xmenu", "--view-main", NULL);
#endif

	return 0;
}



int Run()
{
#if defined(_WIN32)
	static MSG msg ={0};

	if(msg.message==WM_QUIT)
		return -1;

	// check message in queue
	if( PeekMessage( &msg, NULL, 0U, 0U, PM_REMOVE ) )
	{
		::TranslateMessage( &msg );
		::DispatchMessage( &msg );
	}

	Sleep(1);

#endif

	static int frames = 500;

	if(0 == --frames)
		return -1;


	// Rendering
	Render();

	return 0;
}



long CALLBACK MyMsgPrc(HWND hWnd, unsigned int uMsg, unsigned int wParam, long lParam)
{
	long hr = 0;

#if defined(_WIN32)
	switch (uMsg)
	{
		case WM_KEYDOWN:
		{
			if(VK_ESCAPE == wParam)
			{
				SendMessage(hWnd, WM_CLOSE, 0, 0);
				return 0;
			}
			break;
		}

		case WM_CLOSE:
		case WM_DESTROY:
		{
			PostQuitMessage(0);
			return 0;
		}
	}

	hr = DefWindowProc(hWnd, uMsg, wParam, lParam);
#endif

	return hr;
}

