// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"

#define MEDIA_DIR	"../../media/"


int Tga_FileRead(unsigned char** pOutPxl		// Output Pixel
				,	int*	pOutImgW	// Output Image Width
				,	int*	pOutImgH	// Output Image Height
				,	int*	pOutImgC	// Output Image Channel(byte)
				,	char* sFile				// Source File
				);

FixedMesh* LoadMeshFromFile(const char *filename);





CMain::CMain()
{
	m_pMesh	= NULL;
	m_TexID	= 0;
}


int	CMain::Init()
{
	int	hr = 0;



	m_pMesh = LoadMeshFromFile(MEDIA_DIR"model/knot.gsd");



	int	ImgW	= 0;
	int	ImgH	= 0;
	int	ImgC	= 0;
	int	ImgF	= 0;
	unsigned char* pPxl = NULL;


	hr = Tga_FileRead(&pPxl, &ImgW, &ImgH, &ImgC, (char*)MEDIA_DIR"tex/fire128.tga");

	if(0>hr)
		return LC_EFAIL;


	if(3 == ImgC)
		ImgF = GL_RGB;
	else if(4 == ImgC)
		ImgF = GL_RGBA;
	else
		ImgF = GL_LUMINANCE;

	// Generate Texture
	glGenTextures(1, &m_TexID);
	glBindTexture(GL_TEXTURE_2D, m_TexID);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexImage2D(GL_TEXTURE_2D, 0, ImgF, ImgW, ImgH, 0, ImgF, GL_UNSIGNED_BYTE, pPxl);

	free(pPxl);
	glBindTexture(GL_TEXTURE_2D, 0);


	return LC_OK;
}


int	CMain::Destroy()
{
	 //delete mesh data
	free(m_pMesh->Geometry);
	free(m_pMesh->Indices);
	free(m_pMesh->Normals);
	free(m_pMesh->TexCoord);
	free(m_pMesh);


	if(m_TexID)
	{
		glDeleteTextures(1, &m_TexID);
		m_TexID = 0;
	}

	return LC_OK;
}


int	CMain::FrameMove()
{
#if defined(_WIN32)
	LcSys_Sleep(10);
#endif


	static int c=0;
	++c;

	//	if(c>20*60*20)
	if(c>8*60*2)
	{
		printf("Game Process Terminated\n");
		return LC_EFAIL;
	}


	static int n = 0;
	++n;

	if(n>5)
	{
		printf("FPS: %3.f\n", m_fFPS);
		n = 0;
	}






	return LC_OK;
}


int	CMain::Render()
{
	// Setting Rendering pipeline
	glShadeModel(GL_SMOOTH);
	glEnable( GL_DEPTH_TEST);
	glEnable( GL_CULL_FACE );

	glClearColor(0.8f, 0.9f, 1.0f, 1.0f);

	// Clear Color buffer and Depth Buffer.
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);




	SetPerspective();



	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();


	glPushMatrix();
	{
		// Set Model position
		static GLfloat rotation = 0;
		rotation +=0.4f;

		glTranslatef(0, 0, -50);
		glRotatef(30, 1, 0, 0);
		glRotatef(rotation, 0, 1, 0);


		glBindTexture (GL_TEXTURE_2D, m_TexID);
		glEnable(GL_TEXTURE_2D);


		glEnableClientState(GL_VERTEX_ARRAY);		glVertexPointer(  3, GL_FLOAT, 0, m_pMesh->Geometry);
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);glTexCoordPointer(2, GL_FLOAT, 0, m_pMesh->TexCoord);

		glDrawElements(GL_TRIANGLES,m_pMesh->indexCounter,GL_UNSIGNED_SHORT,m_pMesh->Indices);

		glDisableClientState(GL_VERTEX_ARRAY);
		glDisableClientState(GL_TEXTURE_COORD_ARRAY);


		glBindTexture (GL_TEXTURE_2D, 0);
		glDisable(GL_TEXTURE_2D);
	}
	glPopMatrix();


	return LC_OK;
}



void CMain::SetPerspective()
{
	// set up projection matrix in 3d pipeline
	float	temp[16]={0};
	float	width, height;
	glGetFloatv(GL_VIEWPORT, temp);		// get viewport to set the screen width and height.
	width = temp[2];
	height= temp[3];


	float	Asp = (float)width/height;
	float	Near = 1.F;
	float	Far	 = 1000.F;
	float	Fov  = 45.F;

	float	xmin, xmax, ymin, ymax;

	ymax = Near * (float)tan(Fov/2. * 3.14159265358979/180.0);
	ymin = -ymax;

	xmin = ymin * Asp;
	xmax = ymax * Asp;

	glMatrixMode(GL_PROJECTION);					// specify which matrix is the current matrix.
	glLoadIdentity();								// replace the current matrix by the identity matrix
	glFrustumf(xmin, xmax, ymin, ymax, Near, Far);	// multiply the current matrix by the perspective matrix.


	glMatrixMode(GL_MODELVIEW);
}





int Tga_FileRead(unsigned char** pOutPxl	// Output Pixel
				,	int*	pOutImgW		// Output Image Width
				,	int*	pOutImgH		// Output Image Height
				,	int*	pOutImgC		// Output Image Channel(byte)
				,	char* sFile				// Source File
				)
{
	FILE*		fp =NULL;

	// Header
	unsigned char	IDLength	=0;		// ID Length
	unsigned char	ColorMapType=0;		// Color Map Type
	unsigned char	ImageType	=0;		// Image type


	// Color Map Specification
	unsigned short	OffsetMapTable=0;
	unsigned short	ColorMapLength=0;
	unsigned char	ColorBits=0;


	// Image dimensions and format
	unsigned short	x_org =0;			// absolute coordinate of lower-left corner for displays where origin is at the lower left
	unsigned short	y_org =0;			// as for X-origin
//	unsigned short	nImgW =0;			// Image Width
//	unsigned short	nImgH =0;			// Image Height
	unsigned char	nDepth=0;			// Pixel depth: bits per pxl
	unsigned char	ImgDsc=0;			// Image descriptor (1 byte): bits 3-0 give the alpha channel depth, bits 5-4 give direction



	// For Final Targa Data
	unsigned short	nImgW =0;			// Image Width
	unsigned short	nImgH =0;			// Image Height
	unsigned char	nImgC =0;			// Channel Count
	long		nImgSize=0;			// size of TGA image
	unsigned char*	pPxlS = NULL;		// Dest Pixel
	unsigned char*	pPxlT = NULL;		// Temp Pixel


	unsigned char src[8]={0};
	int n=0, i=0, j=0;
	int nRead =0;


	// open the TGA file
	fp = fopen(sFile, "rb" );

	if (!fp)
	{
		printf("TGA File Open Err:%s\n", (char*)sFile);
		return LC_EFAIL;
	}

	// Read 3 bytes
	nRead = fread(&IDLength		, 1, 1, fp);	// Length of the image Id field
	nRead = fread(&ColorMapType	, 1, 1, fp);	// Whether a color map is included
	nRead = fread(&ImageType	, 1, 1, fp);	// Compression and color types

	// Read Color Map Specification
	nRead = fread(&OffsetMapTable, 2, 1, fp);	// First entry index (2 bytes): Offset into the color map table
	nRead = fread(&ColorMapLength, 2, 1, fp);	// Color map length (2 bytes): number of entries
	nRead = fread(&ColorBits     , 1, 1, fp);	// Color map entry size (1 byte): number of bits per pxl

	// Read Image Specification
	nRead = fread(&x_org  , 2, 1, fp);			// X-origin (2 bytes): absolute coordinate of lower-left corner for displays where origin is at the lower left
	nRead = fread(&y_org  , 2, 1, fp);			// Y-origin (2 bytes): as for X-origin
	nRead = fread(&nImgW  , 2, 1, fp);			// Image width (2 bytes): width in pixels
	nRead = fread(&nImgH  , 2, 1, fp);			// Image height (2 bytes): height in pixels
	nRead = fread(&nDepth , 1, 1, fp);			// Pixel depth (1 byte): bits per pxl
	nRead = fread(&ImgDsc , 1, 1, fp);			// Image descriptor (1 byte): bits 3-0 give the alpha channel depth, bits 5-4 give direction


	//	ImageType:
	//	0 no image data is present,
	//	1 uncompressed, color-mapped image,
	//	2 uncompressed, true-color image,
	//	3 uncompressed, black-and-white image,
	//	9 run-length encoded, color-mapped Image,
	//	10 run-length encoded, true-color image and,
	//	11 run-length encoded, black-and-white Image
	if( !(2 == ImageType || 10 == ImageType))
	{
		printf("TGA Err: We can only support only true-color(2 or 10).\n");
		fclose(fp);
		return LC_EFAIL;
	}


	fseek(fp, IDLength + ColorMapType * ColorMapLength, SEEK_CUR);


	// colormode -> 3 = BGR, 4 = BGRA
	nImgC		= nDepth>>3;
	nImgSize	= nImgW * nImgH * nImgC;
	pPxlS		= (unsigned char*)malloc(nImgSize);


	// Uncompressed
	if(2 == ImageType)
	{
		nRead = fread(pPxlS, sizeof(unsigned char), nImgSize, fp);
	}

	// Compressed
	else if(10 == ImageType)
	{
		pPxlT	= pPxlS;

		while (n < nImgW * nImgH)
		{

			if (fread(src, 1, nImgC+1, fp) != (size_t)(nImgC+1))
				break;

			j = src[0] & 0x7f;

			memcpy(&pPxlT[n*nImgC], &src[1], nImgC);
			++n;

			// RLE chunk
			if (src[0] & 0x80)
			{
				for (i=0;i<j;++i)
				{
					memcpy(&pPxlT[n*nImgC], &src[1], nImgC);
					++n;
				}
			}

			// Normal chunk
			else
			{
				for (i=0;i<j;++i)
				{
					if (fread(src, 1, nImgC, fp) != nImgC)
						break;

					memcpy( &pPxlT[n*nImgC], src, nImgC);
					++n;
				}
			}

		}// while

	}

	fclose(fp);


	// bgr to rgb
	for(int y=0; y<nImgH; ++y)
	{
		for(int x=0; x<nImgW; ++x)
		{
			if(3 == nImgC)
			{
				int n = y * nImgW + x;

				int r  = pPxlS[n * nImgC + 0];
				int g  = pPxlS[n * nImgC + 1];
				int b  = pPxlS[n * nImgC + 2];

				pPxlS[n * nImgC + 0] = b;
				pPxlS[n * nImgC + 1] = g;
				pPxlS[n * nImgC + 2] = r;
			}
		}
	}


	// Setting Pixel and Pixel Info
	*pOutPxl  = pPxlS;
	*pOutImgW = nImgW;
	*pOutImgH = nImgH;
	*pOutImgC = nImgC;

	return LC_OK;
}



//Structure to hold the data readed from the file
struct GenericObjectData
{
  char Name[128];
  char ParentName[128];
  unsigned int *Indices;
  GLfloat *Geometry;
  GLfloat *Normals;
  GLfloat *TexCoord;
  unsigned long iC;
  unsigned long vC;
};

//GSD file header
struct GSDHeader
{
  char id[32];
  char version[16];
  int numberOfSubObjects;
};


FixedMesh* LoadMeshFromFile(const char *filename)
{
	GenericObjectData o;
	FixedMesh* mesh= (FixedMesh*)malloc(sizeof(struct FixedMesh));
	unsigned int i;

	struct GSDHeader header;
	FILE *meshFile = fopen(filename,"rb");

	if(!meshFile)
		return NULL;

	/*The header holds a brief description of the file, the version number, and the number of meshes
	that are stored in the file. This type of files are thought for static meshes only*/
	fread(&header,sizeof(struct GSDHeader),1,meshFile);

	//Check if there is at least one object
	if(header.numberOfSubObjects < 1)
		return NULL;

	// we only will use the first object, so we won't iterate over the others, if they exist
	fread(o.Name,sizeof(char)*128,1,meshFile); //read the object name
	fread(o.ParentName,sizeof(char)*128,1,meshFile); //Read the name of the parent object (useful for hierarchies)
	fread(&o.iC,sizeof(unsigned long),1,meshFile); //read the number of vertex indices
	fread(&o.vC,sizeof(unsigned long),1,meshFile); //read the number of vertices

	//allocate enough space for the indices and the GLshort version of them
	o.Indices = (unsigned int *)malloc(sizeof(unsigned int)*(o.iC));
	mesh->Indices = (short *)malloc(sizeof(GLshort)*(o.iC));
	fread(o.Indices, sizeof(unsigned int) * o.iC,1,meshFile); // read all indices

	//allocate enough space for the vertices and the GLfloat version of them
	o.Geometry = (GLfloat *)malloc(sizeof(GLfloat)*(o.vC * 3));
	mesh->Geometry = (GLfloat *)malloc(sizeof(GLfloat)*(o.vC * 3));
	fread(o.Geometry,o.vC * 3 * sizeof(GLfloat),1,meshFile); //read all vertices (1 vertex = 3 floats)

	//allocate enough space for the texture coordinates and the GLfloat version of them
	o.TexCoord = (GLfloat *)malloc(sizeof(GLfloat)*(o.vC * 2));
	mesh->TexCoord = (GLfloat *)malloc(sizeof(GLfloat)*(o.vC * 2));
	fread(o.TexCoord,o.vC * 2 * sizeof(GLfloat),1,meshFile);//read all texcoords (1 tex coord = 2 floats)

	//allocate enough space for the normals and the GLfloat version of them
	o.Normals=(GLfloat *)malloc(sizeof(GLfloat)*(o.vC * 3));
	mesh->Normals = (GLfloat *)malloc(sizeof(GLfloat)*(o.vC * 3));
	fread(o.Normals,o.vC * 3* sizeof(GLfloat),1,meshFile);//read all normals (1 normal = 3 floats)
	fclose(meshFile); //Do not need the file opened anymore

	// Convert data to optimized data types for OpenGL ES (GLfloat and GLshort)
	for(i=0;i<o.vC * 3;i++)
	{
		mesh->Geometry[i]= (o.Geometry[i]);
		mesh->Normals[i] = (o.Normals[i]);
	}

	for(i=0;i<o.vC * 2;i++)
		mesh->TexCoord[i] = (o.TexCoord[i]);

	for(i=0;i<o.iC;i++)
		mesh->Indices[i] = (GLshort)o.Indices[i];

	mesh->indexCounter = (GLshort)o.iC;
	mesh->vertexCounter= (GLshort)o.vC;

	//delete original values, we will use only the optimized ones
	free(o.Indices);
	free(o.Geometry);
	free(o.Normals);
	free(o.TexCoord);

	return mesh;
}


