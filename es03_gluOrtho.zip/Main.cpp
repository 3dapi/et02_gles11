// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#include <math.h>
#include <string.h>

#include "_StdAfx.h"


void MyGluOrtho(float Left, float Right, float Bottom, float Top,float Near, float Far)
{
	float mt[4][4] ={0};

	mt[0][0] = +2/(Right-Left);
	mt[3][0] = -(Right+Left)/(Right-Left);
	mt[1][1] = +2/(Top-Bottom);
	mt[3][1] = -(Top+Bottom)/(Top-Bottom);
	mt[2][2] = -2/(Far-Near);
	mt[3][2] = -(Far+Near)/(Far-Near);
	mt[3][3] = 1;

	glMatrixMode(GL_PROJECTION);
	glLoadMatrixf((const GLfloat*)&mt[0][0]);
	glMatrixMode(GL_MODELVIEW);
}

void MyGluOrtho2D(float Left, float Right, float Bottom, float Top)
{
//	glMatrixMode(GL_PROJECTION);
//	glLoadIdentity();
//	glOrtho(Left, Right, Bottom, Top, -1, 1);

	MyGluOrtho(Left, Right, Bottom, Top, -1, 1);
}



CMain::CMain()
{
}


int	CMain::Init()
{
	return LC_OK;
}

int	CMain::Destroy()
{
	return LC_OK;
}

int	CMain::FrameMove()
{
#if defined(_WIN32)
	LcSys_Sleep(10);
#endif


	static int c=0;
	++c;

	//	if(c>20*60*20)
	if(c>8*60*2)
	{
		printf("Game Process Terminated\n");
		return LC_EFAIL;
	}


	static int n = 0;
	++n;

	if(n>5)
	{
		printf("FPS: %3.f\n", m_fFPS);
		n = 0;
	}

	return LC_OK;
}



int	CMain::Render()
{
	glClearColor(0.8f, 0.9f, 1.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glShadeModel(GL_SMOOTH);		// select smooth shading model.
	glDisable( GL_DEPTH_TEST);		// disable depth test
	glDisable( GL_CULL_FACE );		// disalbe culling face

	MyGluOrtho2D( 0, 400, 300, 0);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	// position buffer
	float vertexArray[8] =
	{
		   0.0F,   0.0F,
		 400.0F,   0.0F,
		 400.0F, 300.0F,
		   0.0F, 300.0F
	};

	// color buffer
	float colorArray[16] =
	{
		1.F, 0.F, 0.F, 1.F,
		0.F, 1.F, 0.F, 1.F,
		0.F, 0.F, 1.F, 1.F,
		1.F, 0.F, 1.F, 1.F
	};



	glEnableClientState(GL_VERTEX_ARRAY);
	glVertexPointer(2, GL_FLOAT, 0, vertexArray);

	glEnableClientState(GL_COLOR_ARRAY);
	glColorPointer(4, GL_FLOAT, 0, colorArray);

	glDrawArrays(GL_TRIANGLE_FAN, 0, 4);


	// disable client-side capability
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_VERTEX_ARRAY);

	return LC_OK;
}



