// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#include <math.h>
#include <string.h>

#include "_StdAfx.h"


void SetProjection()
{
	// set up projection matrix in 3d pipeline
	float	temp[16]={0};
	float	width, height;
	glGetFloatv(GL_VIEWPORT, temp);		// get viewport to set the screen width and height.
	width = temp[2];
	height= temp[3];


	float	Asp = (float)width/height;
	float	Near = 1.F;
	float	Far	 = 1000.F;
	float	Fov  = 45.F;

	float	xmin, xmax, ymin, ymax;

	ymax = Near * (float)tan(Fov/2. * 3.14159265358979/180.0);
	ymin = -ymax;

	xmin = ymin * Asp;
	xmax = ymax * Asp;

	glMatrixMode(GL_PROJECTION);					// specify which matrix is the current matrix.
	glLoadIdentity();								// replace the current matrix by the identity matrix
	glFrustumf(xmin, xmax, ymin, ymax, Near, Far);	// multiply the current matrix by the perspective matrix.


	glMatrixMode(GL_MODELVIEW);
}



void MatrixTranslate(float* Out, float x, float y, float z)
{
	Out[4*3 + 0] = x;
	Out[4*3 + 1] = y;
	Out[4*3 + 2] = z;
}


void MatrixScaling(float* Out, float x, float y, float z)
{
	Out[4*0 + 0] = x;
	Out[4*1 + 1] = y;
	Out[4*2 + 2] = z;
}

void MatrixRotationY(float* Out, float angle)
{
	double radian = angle * 3.14159265358979/180.0;
	float COS = (float)cos(radian);
	float SIN = (float)sin(radian);

	Out[4*0 + 0] = COS;
	Out[4*0 + 2] =-SIN;
	Out[4*1 + 1] = 1;
	Out[4*2 + 0] =+SIN;
	Out[4*2 + 2] = COS;
}


void MatrixMultiple(float* Out, const float* v1, const float* v2)
{
	float t1[16];
	float t2[16];
	int i, j;

	memcpy(t1, v1, sizeof(float)*16);
	memcpy(t2, v2, sizeof(float)*16);


    for (i = 0; i < 4; i++)
	{
		for (j = 0; j < 4; j++)
		{
			Out[i*4+j] = 
			t1[i*4+0] * t2[0*4+j] +
			t1[i*4+1] * t2[1*4+j] +
			t1[i*4+2] * t2[2*4+j] +
			t1[i*4+3] * t2[3*4+j];
		}
    }
}

CMain::CMain()
{
}


int	CMain::Init()
{
	return LC_OK;
}

int	CMain::Destroy()
{
	return LC_OK;
}

int	CMain::FrameMove()
{
#if defined(_WIN32)
	LcSys_Sleep(10);
#endif


	static int c=0;
	++c;

	//	if(c>20*60*20)
	if(c>8*60*2)
	{
		printf("Game Process Terminated\n");
		return LC_EFAIL;
	}


	static int n = 0;
	++n;

	if(n>5)
	{
		printf("FPS: %3.f\n", m_fFPS);
		n = 0;
	}

	return LC_OK;
}



int	CMain::Render()
{
	// Rendering vertex data
	static float pCube[] =
	{
		-10,-10,-10,  +10,-10,-10, +10,+10,-10, -10,+10,-10,
		-10,-10,+10,  +10,-10,+10, +10,+10,+10, -10,+10,+10
	};

	//      7 +----------+ 6
	//       /|         /|
	//      / |        / |
	//     /  |       /  |
	//  3 +----------+ 2 |
	//    |   |      |   |
	//    | 4 +------|---+ 5
	//    |  /       |  /
	//    | /        | /
	//    |/         |/
	//  0 +----------+ 1

	static WORD front[]  = {2,1,3,0};
	static WORD back[]   = {5,6,4,7}; //back face
	static WORD top[]    = {6,2,7,3}; //top face
	static WORD bottom[] = {1,5,0,4}; //bottom face
	static WORD left[]   = {3,0,7,4}; //left face
	static WORD right[]  = {6,5,2,1}; //right face




	// Setting Rendering pipeline
	glShadeModel(GL_SMOOTH);
	glEnable( GL_DEPTH_TEST);
	glEnable( GL_CULL_FACE );

	glClearColor(0.8f, 0.9f, 1.0f, 1.0f);


	// Clear Color buffer and Depth Buffer.
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// setup the projection environment.
	SetProjection();





	float	mtWld[4][4]={0};						// for the model-view matrix.


	glMatrixMode(GL_MODELVIEW);						// specify which matrix is the current matrix to Model-View Matrix.
	glLoadIdentity();

	//push(copy) the current matrix stack
	glPushMatrix();
	{

		static int c =0;
		++c;

		float mtScl[16]={1,0,0,0,  0,1,0,0,  0,0,1,0,  0,0,0,1,  };
		float mtRot[16]={1,0,0,0,  0,1,0,0,  0,0,1,0,  0,0,0,1,  };
		float mtTrs[16]={1,0,0,0,  0,1,0,0,  0,0,1,0,  0,0,0,1,  };

		float mtWld[16]={1,0,0,0,  0,1,0,0,  0,0,1,0,  0,0,0,1,  };
		float mtWld2[16]={1,0,0,0,  0,1,0,0,  0,0,1,0,  0,0,0,1,  };

// use the 3d transform of opengl api
#if 0
		glTranslatef(0.0F, -15.0F, -100.0F);		// multiply the current matrix by a translation matrix
		glRotatef(30.0F, 0.0F,1.0F,0.0F);
		glScalef(3.5F,0.1F,3.5F);
#else
		MatrixTranslate(&mtTrs[0], 0.F, -15.F, -100.F);
		MatrixRotationY(&mtRot[0], (float)(c));
		MatrixScaling(&mtScl[0], 3.5F,0.1F,3.5F);
		MatrixMultiple(&mtWld2[0], &mtScl[0], &mtRot[0]);
		MatrixMultiple(&mtWld2[0], &mtWld2[0], &mtTrs[0]);

		glLoadMatrixf(&mtWld2[0]);
#endif
		



		//Enable the vertices array
		glEnableClientState(GL_VERTEX_ARRAY);

		glVertexPointer(3, GL_FLOAT, 0, pCube);

		glColor4f(1,0,0,1);	glDrawElements(GL_TRIANGLE_STRIP, 4, GL_UNSIGNED_SHORT, front);
		glColor4f(0,1,0,1);	glDrawElements(GL_TRIANGLE_STRIP, 4, GL_UNSIGNED_SHORT, back);
		glColor4f(1,0,1,1);	glDrawElements(GL_TRIANGLE_STRIP, 4, GL_UNSIGNED_SHORT, top);
		glColor4f(1,1,0,1);	glDrawElements(GL_TRIANGLE_STRIP, 4, GL_UNSIGNED_SHORT, bottom);
		glColor4f(0,1,1,1);	glDrawElements(GL_TRIANGLE_STRIP, 4, GL_UNSIGNED_SHORT, left);
		glColor4f(0,0,1,1);	glDrawElements(GL_TRIANGLE_STRIP, 4, GL_UNSIGNED_SHORT, right);

		glDisableClientState(GL_VERTEX_ARRAY);

		glColor4f(1,1,1,1);
	}

	glPopMatrix();

	return LC_OK;
}



